# Delivered five-member native custody

This archive contains exactly five files:

- assets/bet-mark-pocket-and-depletion-v1-light.svg
- assets/bet-mark-pocket-and-depletion-v1-dark.svg
- prompts/bet-mark-pocket-and-depletion-v1.txt
- prompts/bet-mark-pocket-and-depletion-v1-provenance.json
- README.md

The two editable SVGs and design brief are exact original bytes. This provenance JSON and README are derived solely to qualify delivered custody after independent review R1. The original private geometry generator remains privately retained in the immutable original packet. It is NOT included, executable, or promised as delivered here. No private generator locator is projected into the public metadata. The delivered SVGs can be edited as SVG; this archive does not claim to supply their executable original generator.

Use variants.bundlePath from the extracted archive root. variants.path is the separate canonical images/prompts relative locator. No original image-model call occurred; model and creation source commit remain null. No new native image, lesson text, source claim or frozen brief is changed. Fresh successor review, canonical adoption, both live public readers, human review and coverage credit remain pending. No source manuscripts, private calls, runtime captures or private generator are admitted by the archive.
