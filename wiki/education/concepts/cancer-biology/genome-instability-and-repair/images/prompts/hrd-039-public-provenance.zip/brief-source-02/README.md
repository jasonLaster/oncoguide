# HR/HRD source brief: additive markup correction

The complete brief-source-01 and initial independent review remain untouched. This folder changes only the two proposed raw HTML captions to actual HTML source anchors, four source-label/year spaces, and the route alt spelling “with 3′”. Scientific caption sentences, source URLs/depth, molecular composition, all literal light/dark prompt/call bytes and typed frozen task remain exactly as sealed01. Initial scientific/planning acceptance does not approve this changed packet. Fresh exact different-reviewer G1 acceptance and root readiness still precede any image call; G2 has not started.

The two inserted blocks restore the entire original owner bytes exactly when removed. Replacing the corrected blocks with old01 blocks restores the exact prior proposed owner. No original teacher body/map/exercise/metadata/source qualifier changes, native dimensions are still requested placeholders, and no illustration or source-fit/human credit exists.

Only owned corrected proposal artifacts belong to this folder. Original owned unchanged files are referenced explicitly. All original full third-party bodies, literal passage collections and source figures remain local private-source-cache and are excluded from every proposed public bundle. No raw source body is recopied here.
