# HR/HRD source and cartoon brief — no generation

Root selected next-gap-039 for source/brief preparation by multiomics. This is the
first source/prompt handoff, awaiting a different reviewer and root readiness.
No LIGHT, DARK, image model call, canonical insertion, source-fit acceptance,
accounting or human review occurred.

The current public owner was checked by complete header hash before its body was
read. All8,668 bytes equal the frozen original bb046ac8 at auditc1c9 and current
source512d. The exact learner task, gap and LIST guardrails are preserved in
selected-task.json and brief.json. Two small proposed figure blocks remove back
to that complete original, including all teaching prose, source qualifiers,
metadata and generated navigation. Requested width/height values in the proposed
markup are planning values; actual returned native metadata must replace them
before any integration review.

The proposed pair of cartoons serves one owner task:

1. A three-scene physical HR route: prepared3′ tails, RAD51-supported antiparallel
   matching with an intact sister duplex, then a simplified copied/finished region.
2. A compact separate possible history: old chromosome-pattern marks remain while
   repair may recover; a separate question asks for current functional evidence.

The second picture is kept separate so the strand contact and words stay readable.
It does not simulate microscopy, assign a scar score, show a variant causing HRD,
measure a clinical assay or predict response. The route is conditional on a
suitable template after copying and omits much of the finishing machinery.
Core labels are planned large with wrapping at328–368CSSpx image width. Actual
native/embedded and paired-theme reviews remain G2, not a nominal-font proof.

Read route-prompt.txt and history-prompt.txt in full. Each corresponding
light-call-proposed.json contains the exact original `image_gen.imagegen`
argument format (`prompt`, `transparent_background:false`) with no reference.
Dark calls are explicitly pending templates with no actual image reference or
arguments; an independently accepted actual light must later supply that sole
reference. Model is null: no model was invoked or inferred. Both themes must keep
all words, identities, polarity, contact endpoints and geometry aligned.

Fresh official XML was acquired for Jensen2010, Johnson/Jasin2000, Waks2020 and
Cruz2018. The full selected sections and methods/legends are recorded in
source-access.json with actual acquisition hashes and read depth. Johnson/Jasin
returned abstract-only XML, not full Methods. Jensen figure pixels and supplement
requests returned404; no source-image geometry was viewed or copied. Later browser
finds hit a CAPTCHA; the independent official XML remained available. The NCI
dictionary HTML was a JS shell, not a definition; the BRCA fact sheet's selected
VUS paragraph was separately acquired/read. No treatment recommendations from
those papers or the retained lesson are added to the drawings.

Raw third-party XML/HTML, the literal selected-excerpt collection and any source
figure/PDF cache are PRIVATE local-only and excluded by publication-exclusions.json.
The owned public-safe source summary contains short paraphrases, URLs, hash/size,
selected-depth and failure information. No copyrighted figure is a generation
reference. The historical TCR anchor was viewed only for style; its detailed
scientific/patient content has no approval or claim carried into this brief.
The current art direction governs this collection.

G1: different reviewer checks full current owner, exact typed task, every physical
object/arrow/polarity, sources/access depth, both full original-call prompts and
copy/inverse. G2: only after G1+root readiness, inspect actual returned light(s),
measured embedded widths, any correction, then palette-only dark and native pair.
Final canonical/full-task, both-site reader/release and human gates stay separate.
Author byte checks in preparation-validation.json do not approve the science.
