# Two039 original light calls: actual natives, G3 pending

Exactly one original route and one original history image_gen.imagegen call were executed after genuine source/creativeG1/G2 review12a638 and root typed readiness. Each exact JSON argument payload and prompt TXT was saved and displayed first. No reference image, source figure, paper body, raster CPU edit, retry or dark call was used. Tool model identity was not reported and stays null.

Route returned1024×1536; history returned1254×1254 despite the1024-square composition request. Both actual tool outputs remain at their original generated_images paths and were copied byte-exact into this scratch folder. Actual response output_hint strings are preserved; raw image_url base64 is omitted. Metadata is the actual tool result projection, not an API wire/model claim. Both actual natives were personally inspected via returned image and local view_image.

Author observations hold acceptance: route has a reversed Copy information arrow and unapproved Nucleus word; history adds internal text including the palette word SAGE. Independent C must decide the full native physics/copy and ordinary328–368 context before any referenced edit/dark. No phone, nominal font, whole-owner source-fit, deployment, human or credit PASS exists. Browser/UI lock remains with root's other reader work; this author did not call CUA.

All original brief01/corrected02/source/cache and original reviews remain unchanged. Rejected/history native rasters staylocal/tmp; only eventual accepted selected PNGs belong in future public teaching. No raw base64, private case, full third-party body, literal source excerpt collection or figure is added to public provenance. Root alone later selects, integrates and releases.
