# tumor-informed-mrd-assay-comparison-reference-routes-v1

Original editable scientific SVG pair for comparison row 16.

The archive contains exactly five files: two same-geometry theme SVGs, their design brief, provenance JSON and this README. Native dimensions: 780 × 1200; minimum native label size: 32 px.

The diagrams and toy positions are original code-authored constructions. No image-model call, source figure, empirical quantity or clinical performance ranking is represented. Model and creation source commit are null. The observed source snapshot is recorded separately.

The original geometry generator, browser captures and retrieved source bodies are retained privately in the author packet. No executable generator or native screenshot is delivered here. This archive is editable as SVG; it does not claim generator-based reproduction from its own contents.

Selected source passages and retrieval limits are qualified in the provenance. Author checks are not independent peer, expert, learner or both-live-reader approval. All approval and credit states remain pending/zero.
