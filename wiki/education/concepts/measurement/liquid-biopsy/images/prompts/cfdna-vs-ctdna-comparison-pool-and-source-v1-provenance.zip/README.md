# cfdna-vs-ctdna-comparison-pool-and-source-v1

Proposal02, finite R2-UNKNOWN-MEMBERSHIP correction. Original editable scientific SVG pair, native780×1430 with32px minimum labels.

The upper scene defines source classes within cfDNA. The separate source-assignment scene leaves a sampled fragment's ctDNA membership unresolved: neither possible origin route is selected. The known non-tumor source class is distinct from that unknown observation. Yield remains separate from origin. No numerical tumor fraction, live-cell count or clinical performance is represented.

Exactly five members: light/dark SVGs, design brief, provenance JSON and this README. The program, full predecessor/peer/source/attempt records and native/browser captures are privately retained, not delivered here. Editable SVG does not imply executable reproduction from this archive.

No image model was called. Model, image-generation tool, authoringScript and creation source commit are null. Scientific source-depth limits are inherited and recorded; no new retrieval/full-paper claim. Author checks do not grant independent, expert, learner or either live-public-reader approval. Fresh same-nonauthor review is pending; new credit0.
